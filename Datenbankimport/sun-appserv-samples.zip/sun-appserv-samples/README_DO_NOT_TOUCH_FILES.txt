
# *************************************************************************
# ***              LASSEN SIE DIE DATEIEN IN DIESEM VERZEICHNIS UNVERÄNDERT                ***
# *** DATEIEN IN DIESEM VERZEICHNIS UND DESSEN UNTERVERZEICHNISSEN STELLEN EINE DERBY-     ***
# *** DATENBANK DAR; DIE DIE DATEN (BENUTZER UND SYSTEM) UND DIE DATEIEN ENTHÄLT,       ***
# *** DIE FÜR DAS DATENBANK-RECOVERY ERFORDERLICH SIND.                            ***
# *** WENN EINE DIESER DATEIEN BEARBEITET; HINZUGEFÜGT ODER GELÖSCHT WIRD; KÖNNEN DATEN     ***
# *** BESCHÄDIGT WERDEN UND KANN DIE DATENBANK IN EINEN NICHT BEHEBBAREN STATUS VERSETZT WERDEN.     ***
# *************************************************************************